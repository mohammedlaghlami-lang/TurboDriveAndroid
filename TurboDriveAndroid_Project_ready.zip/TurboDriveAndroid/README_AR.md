# Turbo Drive — Android project

هذا مشروع أندرويد أولي يغلّف لعبة Turbo Drive داخل WebView ويعرضها بوضع أفقي وملء الشاشة.

## ما الموجود؟
- `app/src/main/assets/index.html`: ملفات اللعبة.
- `app/src/main/java/com/turbodrive/game/MainActivity.java`: مشغّل اللعبة.
- إعدادات Gradle لبناء APK.

## ملاحظة مهمة
ملف HTML يستخدم مكتبة Three.js من CDN، لذلك يحتاج اتصال إنترنت عند تشغيل اللعبة. لم يتم إرفاق APK جاهز؛ يلزم بناء المشروع باستخدام Android Studio أو بيئة Android SDK.

## بناء APK باستخدام Android Studio
1. فك ضغط المشروع.
2. افتح مجلد `TurboDriveAndroid` في Android Studio.
3. انتظر Gradle Sync وثبّت SDK المطلوبة إذا طُلب ذلك.
4. من القائمة اختر Build > Build APK(s).
5. ملف APK التجريبي سيظهر عادةً داخل `app/build/outputs/apk/debug/app-debug.apk`.

هذا مشروع تجريبي غير موقّع للنشر على المتجر.
